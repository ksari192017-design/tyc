import React, { useState, useRef } from 'react';
import { generateCourseAsset, editUploadedImage } from '../services/geminiService';
import { ImageSize } from '../types';

export const AILab: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'generate' | 'edit'>('generate');

  return (
    <div className="min-h-screen bg-[#0f172a] py-24 px-6 text-white relative overflow-hidden">
      {/* Background Gradients */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-purple-600/10 rounded-full blur-[100px] pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-blue-600/10 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="max-w-6xl mx-auto relative z-10">
        <div className="text-center mb-12">
          <div className="inline-block px-3 py-1 bg-white/10 rounded-full text-xs font-mono text-blue-300 mb-4 border border-white/5 uppercase tracking-widest animate-pulse">
            Launching Soon
          </div>
          <h2 className="text-4xl md:text-5xl font-display font-bold text-white mb-4">TYC Creative Studio</h2>
          <p className="text-slate-400 max-w-2xl mx-auto">Generate professional course assets, thumbnails, and diagrams instantly using next-gen AI.</p>
        </div>

        <div className="relative">
          {/* Overlay for Launching Soon */}
          <div className="absolute inset-0 bg-slate-950/40 backdrop-blur-md z-40 flex flex-col items-center justify-center rounded-3xl border border-white/5">
             <div className="bg-white/10 p-10 rounded-full mb-6 border border-white/10 shadow-2xl">
                <svg className="w-16 h-16 text-blue-400 animate-spin-slow" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.343 17.657l-.707.707m12.728 0l-.707-.707M6.343 6.343l-.707-.707" />
                </svg>
             </div>
             <h3 className="text-3xl font-display font-bold text-white mb-2">Coming Soon!</h3>
             <p className="text-slate-300 text-lg mb-8 max-w-md text-center px-6">We're fine-tuning our AI engines to bring you the best creative tools.</p>
             <button className="px-8 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl shadow-lg shadow-blue-900/40 transition-all">
                Get Notified
             </button>
          </div>

          <div className="glass-dark rounded-3xl overflow-hidden shadow-2xl border border-white/10 min-h-[600px] flex flex-col md:flex-row opacity-30 pointer-events-none grayscale">
            
            {/* Sidebar Navigation */}
            <div className="w-full md:w-64 bg-slate-900/50 border-b md:border-b-0 md:border-r border-white/10 p-6 flex flex-col">
              <h3 className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-6">Tools</h3>
              <div className="space-y-2">
                  <button
                  className={`w-full text-left px-4 py-3 rounded-xl text-sm font-medium transition-all flex items-center gap-3 ${
                      activeTab === 'generate' ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/50' : 'text-slate-400'
                  }`}
                  >
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg>
                  Asset Generator
                  </button>
                  <button
                  className={`w-full text-left px-4 py-3 rounded-xl text-sm font-medium transition-all flex items-center gap-3 text-slate-400`}
                  >
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                  Smart Editor
                  </button>
              </div>
            </div>

            {/* Main Workspace */}
            <div className="flex-1 p-8 bg-slate-900/30">
              <div className="max-w-3xl mx-auto space-y-8">
                <div className="h-40 bg-slate-800/50 rounded-2xl animate-pulse"></div>
                <div className="h-10 bg-slate-800/50 rounded-lg w-1/2 animate-pulse"></div>
                <div className="h-12 bg-slate-800/50 rounded-xl animate-pulse"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const GeneratorTool: React.FC = () => {
  return null; // Implementation kept in the background, but hidden via overlay
};

const EditorTool: React.FC = () => {
  return null; // Implementation kept in the background, but hidden via overlay
};
