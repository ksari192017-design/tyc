import React from 'react';
import { AppSection } from '../types';

interface HeroProps {
  setSection: (section: AppSection) => void;
}

export const Hero: React.FC<HeroProps> = ({ setSection }) => {
  return (
    <div className="relative w-full min-h-screen bg-[#0B1120] text-white flex items-center pt-24 overflow-hidden">
      
      {/* Dynamic Background Elements */}
      <div className="absolute inset-0 bg-[size:40px_40px] bg-grid-pattern opacity-[0.05]"></div>
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-600/20 rounded-full filter blur-[120px] animate-pulse-slow"></div>
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-purple-600/20 rounded-full filter blur-[120px] animate-pulse-slow animation-delay-2000"></div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
          
          {/* Text Content */}
          <div className="lg:w-1/2 text-center lg:text-left animate-fade-in-up">
            <div className="inline-flex items-center space-x-2 bg-white/5 border border-white/10 rounded-full px-4 py-1.5 mb-8 backdrop-blur-sm">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
              </span>
              <span className="text-blue-200 text-xs font-semibold tracking-wide uppercase">AI-Powered Education</span>
            </div>

            <h1 className="text-5xl md:text-7xl font-display font-bold tracking-tight mb-6 leading-tight">
              Master the Future of <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400">Technology</span>
            </h1>
            
            <p className="text-lg md:text-xl text-slate-400 mb-10 leading-relaxed max-w-2xl mx-auto lg:mx-0">
              TYC Edutech combines world-class mentorship with Gemini AI to accelerate your career in coding, data science, and design.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start space-y-4 sm:space-y-0 sm:space-x-6">
              <button 
                onClick={() => setSection(AppSection.COURSES)}
                className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-500 hover:to-violet-500 text-white font-bold rounded-xl shadow-lg shadow-blue-500/25 transition-all transform hover:-translate-y-1 hover:shadow-blue-500/40"
              >
                Start Learning
              </button>
              <button 
                onClick={() => setSection(AppSection.AI_LAB)}
                className="w-full sm:w-auto px-8 py-4 bg-white/5 hover:bg-white/10 border border-white/10 text-white font-semibold rounded-xl backdrop-blur-sm transition-all flex items-center justify-center gap-2 group"
              >
                <span>Try AI Lab</span>
                <svg className="w-5 h-5 text-purple-400 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
              </button>
            </div>

            <div className="mt-12 flex items-center justify-center lg:justify-start space-x-8 text-sm font-medium text-slate-500">
               <div className="flex items-center"><svg className="w-5 h-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg> Verified Certificates</div>
               <div className="flex items-center"><svg className="w-5 h-5 text-blue-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg> Lifetime Access</div>
            </div>
          </div>

          {/* Visual Content / Stats */}
          <div className="lg:w-1/2 relative mt-16 lg:mt-0">
             <div className="relative z-10 animate-float">
                <div className="glass-dark rounded-2xl p-6 border border-white/10 shadow-2xl bg-gradient-to-b from-slate-800/50 to-slate-900/50">
                   {/* Abstract Code UI */}
                   <div className="flex space-x-2 mb-4">
                      <div className="w-3 h-3 rounded-full bg-red-500"></div>
                      <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                      <div className="w-3 h-3 rounded-full bg-green-500"></div>
                   </div>
                   <div className="space-y-3 font-mono text-sm">
                      <div className="flex"><span className="text-purple-400 w-8">01</span> <span className="text-blue-300">import</span> <span className="text-white">Future</span> <span className="text-blue-300">from</span> <span className="text-green-300">'@tyc/edutech'</span>;</div>
                      <div className="flex"><span className="text-purple-400 w-8">02</span></div>
                      <div className="flex"><span className="text-purple-400 w-8">03</span> <span className="text-blue-300">const</span> <span className="text-yellow-300">student</span> = <span className="text-blue-300">await</span> <span className="text-white">Future.learn();</span></div>
                      <div className="flex"><span className="text-purple-400 w-8">04</span> <span className="text-blue-300">if</span> (<span className="text-white">student.skills</span> > <span className="text-orange-300">9000</span>) {'{'}</div>
                      <div className="flex"><span className="text-purple-400 w-8">05</span> &nbsp;&nbsp;<span className="text-white">career.launch(</span><span className="text-green-300">"Success"</span><span className="text-white">);</span></div>
                      <div className="flex"><span className="text-purple-400 w-8">06</span> {'}'}</div>
                   </div>
                   
                   {/* Floating Stats Cards */}
                   <div className="absolute -right-8 -bottom-8 glass-dark p-4 rounded-xl border border-white/10 shadow-xl flex items-center gap-3 animate-pulse-slow">
                      <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center text-green-400">
                        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>
                      </div>
                      <div>
                        <div className="text-xs text-slate-400">Avg Salary Hike</div>
                        <div className="text-lg font-bold text-white">+150%</div>
                      </div>
                   </div>

                   <div className="absolute -left-8 -top-8 glass-dark p-4 rounded-xl border border-white/10 shadow-xl flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400">
                        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
                      </div>
                      <div>
                        <div className="text-xs text-slate-400">Learners</div>
                        <div className="text-lg font-bold text-white">10k+</div>
                      </div>
                   </div>

                </div>
             </div>
             {/* Glow effect behind visual */}
             <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-full blur-3xl -z-10"></div>
          </div>

        </div>
      </div>
    </div>
  );
};