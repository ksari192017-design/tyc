import React from 'react';
import { Event } from '../types';

const EVENTS: Event[] = [
  { id: '1', title: 'Website Building using AI', date: 'Jan 17 - 18, 2026', type: 'Workshop', price: '₹50' },
  { id: '2', title: 'Building AI Agents', date: 'Jan 24 - 25, 2026', type: 'Workshop', price: '₹99' },
  { id: '3', title: 'LinkedIn & Resume Strategy', date: 'Jan 31 - Feb 1, 2026', type: 'Webinar', price: 'Free' },
  { id: '4', title: 'Portfolio Building Mastery', date: 'Feb 7 - 8, 2026', type: 'Workshop', price: '₹149' },
];

export const Webinars: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 py-24 px-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-20">
           <h2 className="text-4xl font-display font-bold text-slate-900">Live Events 2026</h2>
           <p className="text-slate-500 mt-3 text-lg">Join expert-led sessions to stay ahead of the curve.</p>
        </div>

        <div className="relative space-y-12 before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-slate-300 before:to-transparent">
          {EVENTS.map((event, idx) => (
             <div key={event.id} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group">
                
                {/* Timeline Dot */}
                <div className="absolute left-0 md:left-1/2 -translate-x-1.5 md:-translate-x-1/2 mt-1.5 w-4 h-4 rounded-full bg-slate-200 border-4 border-white shadow-sm group-hover:bg-blue-500 group-hover:scale-125 transition-all z-10"></div>
                
                {/* Card */}
                <div className="flex w-full md:w-[calc(50%-2rem)] pl-10 md:pl-0">
                    <div className="w-full bg-white p-6 rounded-2xl shadow-sm border border-slate-100 group-hover:shadow-xl group-hover:border-blue-200 transition-all duration-300">
                        <div className="flex justify-between items-start mb-2">
                            <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded ${event.type === 'Webinar' ? 'bg-blue-50 text-blue-600' : 'bg-purple-50 text-purple-600'}`}>
                                {event.type}
                            </span>
                            <span className={`text-sm font-bold ${event.price === 'Free' ? 'text-green-600' : 'text-slate-900'}`}>
                                {event.price}
                            </span>
                        </div>
                        <h3 className="text-lg font-bold text-slate-900 mb-2 group-hover:text-blue-600 transition-colors">{event.title}</h3>
                        <div className="flex items-center text-slate-500 text-sm mb-4">
                           <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                           {event.date}
                        </div>
                        <button className="w-full py-2 rounded-lg border border-slate-200 text-slate-600 text-sm font-semibold hover:bg-slate-900 hover:text-white hover:border-slate-900 transition-colors">
                            Register Now
                        </button>
                    </div>
                </div>
             </div>
          ))}
        </div>
      </div>
    </div>
  );
};