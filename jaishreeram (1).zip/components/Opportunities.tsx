import React, { useState } from 'react';
import { Job } from '../types';
import { SignedIn } from '@clerk/clerk-react';

export const Opportunities: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 py-24 px-6 relative overflow-hidden">
      {/* Coming Soon Overlay */}
      <div className="absolute inset-0 z-50 bg-slate-50/90 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center">
         <div className="bg-indigo-100 p-6 rounded-full mb-8 border border-indigo-200 shadow-xl">
            <svg className="w-12 h-12 text-indigo-600 animate-pulse" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
         </div>
         <h2 className="text-4xl font-display font-bold text-slate-900 mb-4">Career Opportunities</h2>
         <div className="inline-block bg-indigo-600 text-white px-5 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest mb-6">Coming Soon</div>
         <p className="text-lg text-slate-500 max-w-lg mb-10">
           We're curating the best jobs and internships from the world's leading tech companies. Your dream career is just around the corner.
         </p>
         <button className="px-8 py-3 bg-slate-900 text-white font-bold rounded-xl shadow-lg transition-all hover:scale-105">
            Notify Me of Openings
         </button>
      </div>

      <div className="max-w-4xl mx-auto opacity-10 pointer-events-none grayscale">
        <div className="text-center mb-16">
            <h2 className="text-4xl font-display font-bold text-slate-900">Career Opportunities</h2>
            <p className="text-slate-500 mt-2 text-lg">Curated jobs and internships from top tech companies.</p>
        </div>
      </div>
    </div>
  );
};