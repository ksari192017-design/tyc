import React from 'react';
import { AppSection } from '../types';
import { SignedIn, SignedOut, UserButton } from '@clerk/clerk-react';

interface NavbarProps {
  currentSection: AppSection;
  setSection: (section: AppSection) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentSection, setSection }) => {
  const navLinkClass = (section: AppSection) =>
    `relative px-3 py-2 text-sm font-medium transition-all duration-300 rounded-lg group ${
      currentSection === section 
        ? 'text-white bg-white/10 shadow-inner' 
        : 'text-slate-400 hover:text-white hover:bg-white/5'
    }`;

  return (
    <nav className="absolute w-full top-0 z-50 transition-all duration-300">
      <div className="absolute inset-0 bg-[#0B1120]/90 backdrop-blur-xl border-b border-white/5 shadow-lg"></div>
      
      <div className="container mx-auto px-6 relative">
        <div className="flex flex-col lg:flex-row items-center justify-between py-4">
          
          {/* Logo Section */}
          <div className="flex items-center space-x-3 cursor-pointer self-start lg:self-auto mb-4 lg:mb-0" onClick={() => setSection(AppSection.HOME)}>
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 to-violet-600 rounded-lg blur opacity-40 group-hover:opacity-75 transition duration-1000 group-hover:duration-200"></div>
              <div className="relative bg-black rounded-lg p-0.5 border border-white/10 overflow-hidden flex items-center justify-center h-10 w-10">
                 <img 
                    src="https://ibb.co/Y7zdKFRD" 
                    alt="TYC Logo" 
                    className="h-full w-full object-cover rounded-md"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = "https://ui-avatars.com/api/?name=TYC&background=0D8ABC&color=fff";
                    }}
                  />
              </div>
            </div>
            <span className="text-xl font-display font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400 tracking-tight">
              TYC Edutech
            </span>
          </div>

          {/* Navigation Links */}
          <div className="flex items-center gap-2 overflow-x-auto w-full lg:w-auto pb-2 lg:pb-0 hide-scrollbar px-2">
            {[
              { id: AppSection.HOME, label: 'Home' },
              { id: AppSection.COURSES, label: 'Courses' },
              { id: AppSection.MATERIALS, label: 'Materials' },
              { id: AppSection.JOBS, label: 'Jobs' },
              { id: AppSection.FREELANCE, label: 'Freelance' },
              { id: AppSection.WEBINARS, label: 'Webinars' },
              { id: AppSection.RESUME, label: 'Resume AI' },
              { id: AppSection.AI_LAB, label: 'AI Lab' },
            ].map((item) => (
              <button 
                key={item.id}
                onClick={() => setSection(item.id)} 
                className={navLinkClass(item.id)}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Auth Buttons */}
          <div className="hidden lg:flex items-center space-x-4 ml-4">
            <SignedOut>
                <button 
                    onClick={() => setSection(AppSection.LOGIN)}
                    className="text-sm font-medium text-slate-400 hover:text-white transition-colors"
                >
                    Log In
                </button>
                <button 
                    onClick={() => setSection(AppSection.LOGIN)}
                    className="group relative px-6 py-2 rounded-full bg-blue-600 text-white text-sm font-semibold shadow-lg shadow-blue-500/30 hover:bg-blue-500 transition-all overflow-hidden"
                >
                <span className="relative z-10">Join Now</span>
                <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-purple-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </button>
            </SignedOut>
            <SignedIn>
                <div className="flex items-center gap-3">
                    <span className="text-xs text-slate-400">Welcome!</span>
                    <UserButton afterSignOutUrl="/" />
                </div>
            </SignedIn>
          </div>
        </div>
      </div>
    </nav>
  );
};