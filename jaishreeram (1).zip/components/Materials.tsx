import React, { useState } from 'react';
import { Material } from '../types';
import { SignedIn } from '@clerk/clerk-react';

const INITIAL_MATERIALS: Material[] = [
  { id: '1', title: 'Advanced Physics Notes (Year 2)', type: 'PDF', price: '₹30', isFree: false },
  { id: '2', title: 'Organic Chemistry Masterclass', type: 'PDF', price: 'Free', isFree: true },
  { id: '3', title: 'Calculus & Algebra Cheat Sheet', type: 'PDF', price: 'Free', isFree: true },
  { id: '4', title: 'Java Interview Blueprint', type: 'PDF', price: '₹100', isFree: false },
  { id: '5', title: 'Data Structures Algorithms Guide', type: 'PDF', price: '₹50', isFree: false },
  { id: '6', title: 'System Design Interview Prep', type: 'PDF', price: 'Free', isFree: true },
  { 
    id: '7', 
    title: 'Python Zero to Hero Notes', 
    type: 'PDF', 
    price: 'Free', 
    isFree: true, 
    downloadUrl: 'https://drive.google.com/file/d/1pjv8iTv79WbJ2rIztGEouAELUCBZd5m9/view?usp=drivesdk' 
  },
  { 
    id: '8', 
    title: 'Role-Based Skills Roadmap', 
    type: 'PDF', 
    price: 'Free', 
    isFree: true, 
    downloadUrl: 'https://drive.google.com/file/d/1IMR5Ptj1Ens_WCNCSa3HHJKXmkDmSNCo/view?usp=drivesdk' 
  }
];

export const Materials: React.FC = () => {
  const [materials, setMaterials] = useState<Material[]>(INITIAL_MATERIALS);
  const [isAdding, setIsAdding] = useState(false);
  const [newMaterial, setNewMaterial] = useState<Partial<Material>>({ type: 'PDF', isFree: true });

  const handleAdd = () => {
      if (newMaterial.title) {
          setMaterials([...materials, {
              ...newMaterial,
              id: Date.now().toString(),
              price: newMaterial.isFree ? 'Free' : (newMaterial.price || '₹0'),
              type: newMaterial.type || 'PDF'
          } as Material]);
          setNewMaterial({ type: 'PDF', isFree: true });
          setIsAdding(false);
      }
  };

  const handleDelete = (id: string) => {
      if (confirm("Delete this material?")) {
          setMaterials(materials.filter(m => m.id !== id));
      }
  };

  return (
    <div className="min-h-screen bg-slate-50 py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-12 text-center">
           <span className="text-blue-600 font-bold tracking-widest text-xs uppercase bg-blue-50 px-3 py-1 rounded-full">Resources</span>
           <h2 className="text-4xl font-display font-bold text-slate-900 mt-4 mb-2">Study Materials</h2>
           <p className="text-slate-500 text-lg">Curated notes and guides to help you excel.</p>
        </div>

        <SignedIn>
            <div className="flex justify-center mb-8">
                <button onClick={() => setIsAdding(!isAdding)} className="bg-slate-900 text-white px-6 py-2 rounded-full font-bold shadow hover:bg-slate-800">
                    {isAdding ? 'Close Uploader' : 'Upload Material'}
                </button>
            </div>
            {isAdding && (
                <div className="max-w-xl mx-auto bg-white p-6 rounded-2xl shadow-xl border border-slate-200 mb-10">
                    <h3 className="font-bold text-lg mb-4">Upload New Material</h3>
                    <div className="space-y-4">
                        <input className="w-full p-2 border rounded" placeholder="Title" value={newMaterial.title || ''} onChange={e => setNewMaterial({...newMaterial, title: e.target.value})} />
                        <div className="flex gap-4">
                            <select className="p-2 border rounded flex-1" value={newMaterial.type} onChange={e => setNewMaterial({...newMaterial, type: e.target.value as any})}>
                                <option value="PDF">PDF Document</option>
                                <option value="Video">Video Course</option>
                            </select>
                            <label className="flex items-center gap-2 cursor-pointer border p-2 rounded px-4">
                                <input type="checkbox" checked={newMaterial.isFree} onChange={e => setNewMaterial({...newMaterial, isFree: e.target.checked})} />
                                <span className="text-sm font-medium">Is Free?</span>
                            </label>
                        </div>
                        {!newMaterial.isFree && (
                             <input className="w-full p-2 border rounded" placeholder="Price (e.g. ₹50)" value={newMaterial.price || ''} onChange={e => setNewMaterial({...newMaterial, price: e.target.value})} />
                        )}
                        <input className="w-full p-2 border rounded" placeholder="Download URL (Optional)" value={newMaterial.downloadUrl || ''} onChange={e => setNewMaterial({...newMaterial, downloadUrl: e.target.value})} />
                        <button onClick={handleAdd} className="w-full bg-blue-600 text-white py-2 rounded-lg font-bold hover:bg-blue-700">Add Material</button>
                    </div>
                </div>
            )}
        </SignedIn>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {materials.map((item) => (
            <div key={item.id} className="group bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-xl hover:border-blue-200 transition-all duration-300 flex items-start gap-4 cursor-pointer relative">
              <div className={`w-14 h-14 rounded-2xl flex-shrink-0 flex items-center justify-center transition-colors ${item.isFree ? 'bg-green-50 text-green-600 group-hover:bg-green-100' : 'bg-blue-50 text-blue-600 group-hover:bg-blue-100'}`}>
                 {item.type === 'PDF' ? (
                     <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
                 ) : (
                     <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                 )}
              </div>
              <div className="flex-1 min-w-0">
                 <div className="flex justify-between items-start mb-1">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wide ${item.isFree ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-700'}`}>
                        {item.isFree ? 'Free' : item.price}
                    </span>
                 </div>
                 <h3 className="font-bold text-slate-800 leading-snug truncate pr-2 mb-3" title={item.title}>{item.title}</h3>
                 
                 {item.downloadUrl ? (
                    <a 
                    href={item.downloadUrl} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-sm font-semibold text-blue-600 hover:text-blue-800 flex items-center group/link"
                    >
                        Download Now 
                        <svg className="w-4 h-4 ml-1 transform group-hover/link:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
                    </a>
                 ) : (
                    <button className="text-sm font-semibold text-slate-400 hover:text-slate-600 flex items-center">
                        View Details
                    </button>
                 )}
              </div>

              <SignedIn>
                 <button 
                    onClick={(e) => { e.stopPropagation(); handleDelete(item.id); }}
                    className="absolute -top-2 -right-2 bg-red-500 text-white w-6 h-6 rounded-full flex items-center justify-center shadow hover:bg-red-600 opacity-0 group-hover:opacity-100 transition-opacity"
                 >
                    &times;
                 </button>
              </SignedIn>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};