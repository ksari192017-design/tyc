import React, { useState } from 'react';
import { Course } from '../types';

const COURSES_DATA: Course[] = [
  {
    id: '1',
    title: 'Java Full Stack Development',
    description: 'Master Java, Spring Boot, React, and AWS with live expert guidance.',
    instructor: 'Rahul Verma',
    price: '₹15,000',
    category: 'Full Stack',
    level: 'Advanced',
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=500&q=80',
    rating: 4.9,
    type: 'Live',
    startDate: 'Oct 26, 2026'
  },
  {
    id: '2',
    title: 'Data Science & AI Masterclass',
    description: 'Deep dive into Python, ML algorithms, and Neural Networks.',
    instructor: 'Dr. S. Gupta',
    price: '₹18,000',
    category: 'Data Science',
    level: 'Advanced',
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=500&q=80',
    rating: 4.8,
    type: 'Live',
    startDate: 'Nov 1, 2026'
  },
  {
    id: '3',
    title: 'HTML Basics',
    description: 'Start your web journey. Understanding DOM, Semantic HTML, and SEO.',
    instructor: 'Team TYC',
    price: '₹200',
    category: 'Web Dev',
    level: 'Beginner',
    image: 'https://images.unsplash.com/photo-1542831371-d531d36971e6?w=500&q=80',
    rating: 4.5,
    type: 'Recorded'
  },
  {
    id: '4',
    title: 'Dev Career Path',
    description: 'Complete guide to navigating the industry, salaries, and interview prep.',
    instructor: 'Career Coach Mike',
    price: '₹50',
    category: 'Career',
    level: 'All Levels',
    image: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=500&q=80',
    rating: 4.7,
    type: 'Recorded'
  },
  {
    id: '5',
    title: 'Python for Beginners',
    description: 'Self-paced python basics. Loops, functions, and data structures.',
    instructor: 'Anita Roy',
    price: '₹499',
    category: 'Programming',
    level: 'Beginner',
    image: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=500&q=80',
    rating: 4.6,
    type: 'Recorded'
  }
];

export const Courses: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'Live' | 'Recorded'>('Live');
  const filteredCourses = COURSES_DATA.filter(c => c.type === activeTab);

  return (
    <div className="bg-slate-50 min-h-screen py-24 px-6 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-96 bg-gradient-to-b from-blue-50 to-slate-50 -z-10"></div>

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center mb-16">
          <span className="text-accent font-bold tracking-wider text-sm uppercase">World Class Learning</span>
          <h2 className="text-4xl md:text-5xl font-display font-bold text-slate-900 mt-2 mb-4">Explore Our Courses</h2>
          <p className="text-slate-500 max-w-2xl mx-auto text-lg">Designed by industry experts to help you learn real-world skills.</p>
        </div>

        {/* Custom Tab Switcher */}
        <div className="flex justify-center mb-14">
          <div className="bg-white p-1.5 rounded-2xl shadow-lg shadow-slate-200/50 border border-slate-100 inline-flex relative">
            <button
              onClick={() => setActiveTab('Live')}
              className={`relative z-10 px-8 py-3 rounded-xl text-sm font-bold transition-all duration-300 flex items-center gap-2 ${
                activeTab === 'Live' ? 'text-white' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <div className={`w-2 h-2 rounded-full ${activeTab === 'Live' ? 'bg-red-400 animate-pulse' : 'bg-slate-300'}`}></div>
              Live Classes
            </button>
            <button
              onClick={() => setActiveTab('Recorded')}
              className={`relative z-10 px-8 py-3 rounded-xl text-sm font-bold transition-all duration-300 flex items-center gap-2 ${
                activeTab === 'Recorded' ? 'text-white' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <div className={`w-2 h-2 rounded-full ${activeTab === 'Recorded' ? 'bg-purple-300' : 'bg-slate-300'}`}></div>
              Recorded
            </button>
            
            {/* Sliding background */}
            <div 
                className={`absolute top-1.5 bottom-1.5 rounded-xl bg-slate-900 transition-all duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] shadow-md`}
                style={{
                    left: activeTab === 'Live' ? '6px' : '50%',
                    width: 'calc(50% - 6px)',
                    transform: activeTab === 'Recorded' ? 'translateX(-3px)' : 'none'
                }}
            ></div>
          </div>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredCourses.map(course => (
            <div key={course.id} className="group bg-white rounded-3xl shadow-sm hover:shadow-2xl hover:shadow-blue-500/10 transition-all duration-500 border border-slate-100 overflow-hidden flex flex-col hover:-translate-y-2">
              
              {/* Image Section */}
              <div className="relative overflow-hidden h-56">
                <div className="absolute inset-0 bg-slate-900/10 group-hover:bg-transparent transition-colors z-10"></div>
                <img 
                  src={course.image} 
                  alt={course.title} 
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute top-4 left-4 z-20 flex gap-2">
                    <span className="bg-white/90 backdrop-blur-md text-slate-900 text-xs font-bold px-3 py-1.5 rounded-lg shadow-sm">
                        {course.category}
                    </span>
                </div>
                {course.startDate && (
                    <div className="absolute bottom-4 right-4 z-20 bg-slate-900/90 backdrop-blur text-white px-3 py-1.5 rounded-lg text-xs font-medium border border-white/10 flex items-center shadow-lg">
                        <svg className="w-3 h-3 mr-1.5 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                        {course.startDate}
                    </div>
                )}
              </div>

              {/* Content Section */}
              <div className="p-7 flex-1 flex flex-col">
                <div className="flex justify-between items-center mb-3">
                    <div className="flex items-center text-amber-500 text-sm font-bold">
                        <svg className="w-4 h-4 mr-1 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                        {course.rating}
                    </div>
                    <span className="text-xs font-semibold text-slate-400 uppercase tracking-wide">{course.level}</span>
                </div>

                <h3 className="font-display font-bold text-slate-900 text-xl mb-3 leading-tight group-hover:text-blue-600 transition-colors">{course.title}</h3>
                <p className="text-slate-500 text-sm mb-6 flex-grow leading-relaxed">{course.description}</p>
                
                <div className="pt-5 border-t border-slate-100">
                    <div className="flex items-center justify-between mb-5">
                        <div className="flex items-center space-x-2">
                             <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-xs font-bold text-slate-600">
                                {course.instructor.charAt(0)}
                             </div>
                             <div>
                                 <p className="text-xs text-slate-400">Instructor</p>
                                 <p className="text-xs font-bold text-slate-700">{course.instructor}</p>
                             </div>
                        </div>
                        <div className="text-right">
                             <span className="block text-xl font-bold text-slate-900">{course.price}</span>
                        </div>
                    </div>
                    
                    <button className="w-full py-3.5 bg-slate-900 text-white font-semibold rounded-xl hover:bg-gradient-to-r hover:from-blue-600 hover:to-violet-600 transition-all shadow-lg shadow-slate-200 hover:shadow-blue-500/30 flex items-center justify-center gap-2">
                      {course.type === 'Live' ? 'Reserve Seat' : 'Buy Course'}
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" /></svg>
                    </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};