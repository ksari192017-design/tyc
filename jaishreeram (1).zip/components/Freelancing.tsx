import React, { useState } from 'react';
import { SignedIn } from '@clerk/clerk-react';

export const Freelancing: React.FC = () => {
  return (
    <div className="min-h-screen bg-white py-24 px-6 relative overflow-hidden">
      {/* Coming Soon Overlay */}
      <div className="absolute inset-0 z-50 bg-white/80 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center">
         <div className="inline-block bg-blue-100 text-blue-700 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider mb-6 animate-bounce">Coming Soon</div>
         <h2 className="text-5xl font-display font-bold text-slate-900 mb-6">TYC Connect</h2>
         <p className="text-xl text-slate-500 max-w-lg mb-8">
           We are building a bridge between talented students and high-growth startups. Start earning while you learn.
         </p>
         <div className="flex flex-col sm:flex-row gap-4">
            <button className="px-8 py-3 bg-slate-900 text-white font-bold rounded-xl shadow-xl transition-all hover:scale-105">
               Notify Me
            </button>
            <button className="px-8 py-3 bg-white border border-slate-200 text-slate-600 font-bold rounded-xl transition-all">
               Learn More
            </button>
         </div>
      </div>

      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-20 items-center opacity-20 pointer-events-none grayscale">
        <div>
          <div className="inline-block bg-yellow-50 text-yellow-700 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider mb-6">Beta Access</div>
          <h2 className="text-5xl font-display font-bold text-slate-900 mb-6 leading-tight">
            Turn Your Skills Into <br /><span className="text-blue-600">Income.</span>
          </h2>
          <p className="text-xl text-slate-500 mb-10 leading-relaxed">
            TYC Connect bridges the gap between students and startups. Work on real projects, build your portfolio, and earn while you learn.
          </p>
        </div>
      </div>
    </div>
  );
};