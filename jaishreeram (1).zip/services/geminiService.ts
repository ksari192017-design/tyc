import { GoogleGenAI, GenerateContentResponse, Chat } from "@google/genai";
import { ImageSize } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

// 1. Chatbot (Gemini 3 Pro Preview)
export const createChatSession = () => {
  return ai.chats.create({
    model: 'gemini-3-pro-preview',
    config: {
      systemInstruction: "You are a helpful, encouraging, and knowledgeable AI tutor for TYC Edutech. You help students with programming concepts, course recommendations, and career advice.",
    },
  });
};

// 2. Search Grounding (Gemini 2.5 Flash)
export const searchTechTrends = async (query: string): Promise<string> => {
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: query,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const text = response.text || "No results found.";
    
    // Process grounding chunks if available
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    let sources = "";
    if (chunks) {
      const urls = chunks
        .map((chunk: any) => chunk.web?.uri)
        .filter((url: string | undefined) => url)
        .join(', ');
      if (urls) {
        sources = `\n\nSources: ${urls}`;
      }
    }
    
    return text + sources;
  } catch (error) {
    console.error("Search Error:", error);
    throw new Error("Failed to fetch tech trends.");
  }
};

// 3. Image Generation (Gemini 3 Pro Image Preview)
export const generateCourseAsset = async (prompt: string, size: ImageSize): Promise<string> => {
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: {
        parts: [{ text: prompt }],
      },
      config: {
        imageConfig: {
          imageSize: size,
          aspectRatio: "16:9" // Good for course thumbnails
        }
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    throw new Error("No image generated.");
  } catch (error) {
    console.error("Image Gen Error:", error);
    throw error;
  }
};

// 4. Image Editing (Gemini 2.5 Flash Image)
export const editUploadedImage = async (base64Image: string, prompt: string): Promise<string> => {
  try {
    const cleanBase64 = base64Image.split(',')[1];

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/png', // Assuming PNG for simplicity
              data: cleanBase64,
            },
          },
          {
            text: prompt,
          },
        ],
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    throw new Error("No edited image returned.");
  } catch (error) {
    console.error("Image Edit Error:", error);
    throw error;
  }
};

// 5. Resume Generation (Gemini 3 Pro Preview)
export const generateResume = async (data: any): Promise<string> => {
  try {
    const prompt = `
      You are an expert Resume Writer and Career Coach. Create a professional, ATS-friendly resume for a Fresher based strictly on the following details provided by the user.

      DATA:
      ${JSON.stringify(data, null, 2)}

      STRUCTURE & FORMATTING RULES:
      1.  **Header**: Center align Name, Phone, Email, Location, LinkedIn, Portfolio.
      2.  **Career Objective**: Use the one provided or refine it to be impactful (1 sentence).
      3.  **Education**: List Degree, College, Year, CGPA.
      4.  **Technical Skills**: Group by Languages, Tools, Databases, etc.
      5.  **Projects**: Bullet points. Use strong action verbs (Developed, Designed, etc.). Highlight the tech stack used.
      6.  **Internships/Training**: Format as Role @ Company. Focus on responsibilities and outcomes.
      7.  **Certifications**: List Course & Platform.
      8.  **Achievements**: Bullet points.
      9.  **Soft Skills**: Comma separated or bulleted.
      10. **Extra-Curricular**: Bullet points.

      OUTPUT STYLE:
      - Use Markdown formatting.
      - Use **Bold** for Section Headers (e.g., **EDUCATION**, **PROJECTS**).
      - Use bullet points (-) for list items.
      - Clean, minimalistic, professional tone.
      - NO explanations, just the resume content.
    `;

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
    });

    return response.text || "Failed to generate resume.";
  } catch (error) {
    console.error("Resume Gen Error:", error);
    throw error;
  }
};